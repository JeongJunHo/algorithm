package day01;

public class 최빈수구하기 {

}
